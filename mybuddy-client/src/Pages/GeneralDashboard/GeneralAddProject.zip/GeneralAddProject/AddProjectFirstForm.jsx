import DescriptionTextArea from "./DescriptionTextArea";
import next from "../../../assets/next.png";
import PropTypes from "prop-types";
import { useState } from "react";

const AddProjectFirstForm = ({ handleFirst, onFormChange }) => {
  const [formData, setFormData] = useState({
    // Define initial state for this form's fields
    projectName: "",
    description: "",
    // ... other fields
  });
  const handleDescriptionChange = (description) => {
    onFormChange("description", description);
    console.log("f", description);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    onFormChange(name, value);
  };
  return (
    <form className="p-3llg:p-6  w-11/12 space-y-2">
      {/* project name */}
      <div className="w-10/12 md:w-5/12 lg:w-4/12 flex flex-col space-y-2 font-medium gray600">
        <label className="text-[16px] md:text-xl">Project name</label>
        <input
          name="projectName"
          value={formData.projectName}
          onChange={handleInputChange}
          className="rounded-lg py-3 bg-[#c6e3f2] shadow-[-5px_-5px_20px_rgba(255,_255,_255,_0.8)_inset,_5px_5px_20px_rgba(0,_0,_0,_0.2)_inset] box-border border-[0.5px] border-solid border-gray-100"
        />
      </div>
      {/* description */}
      <div className="flex flex-col space-y-2 w-full font-medium gray600">
        <label className="text-[16px] md:text-xl border-b-2 border-white py-2">
          Description
        </label>
        <DescriptionTextArea
          handleDescriptionChange={handleDescriptionChange}
          setFormData={setFormData}
        />
      </div>
      <div onClick={handleFirst} className="float-right">
        <img src={next} className="h-12" />
      </div>
    </form>
  );
};

export default AddProjectFirstForm;
AddProjectFirstForm.propTypes = {
  handleFirst: PropTypes.func,
};
